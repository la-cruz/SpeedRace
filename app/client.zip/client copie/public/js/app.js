import "purecss/build/pure-min.css";
import "leaflet/dist/leaflet.css";
import '../css/style.css';
import "./main";
